# 五码注入完整流程

## 生产流程概览

```
┌─────────────────────────────────────────────────────────────────┐
│                    第一阶段：虚拟机准备                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  1. 创建macOS虚拟机                                             │
│     └── setup_vm.sh                                             │
│                                                                 │
│  2. 安装Clover EFI引导                                          │
│     └── Clover Configurator GUI                                 │
│                                                                 │
│  3. 五码注入 (本项目核心)                                        │
│     ├── 方式A: clover_configurator.sh (命令行)                  │
│     └── 方式B: Clover Configurator (GUI)                         │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                    第二阶段：Clover五码配置                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Clover EFI分区                                                 │
│  └── EFI/                                                       │
│      └── CLOVER/                                                │
│          ├── config.plist  ← 五码主配置                          │
│          └── SMBIOS.plist  ← SMBIOS信息                         │
│                                                                 │
│  五码字段映射:                                                  │
│  ┌────────────────┬────────────────────────────────┐           │
│  │ 五码名称       │ Clover字段                     │           │
│  ├────────────────┼────────────────────────────────┤           │
│  │ UUID           │ SystemParameters.UUID          │           │
│  │ BoardSerial    │ SMBIOS.BoardSerialNumber       │           │
│  │ Serial         │ SMBIOS.SerialNumber            │           │
│  │ ROM            │ RtVariables.ROM                │           │
│  │ MLB            │ RtVariables.MLB                │           │
│  │ SmUUID         │ SMBUUID                       │           │
│  └────────────────┴────────────────────────────────┘           │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                    第三阶段：验证五码生效                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  # 终端验证                                                     │
│  system_profiler SPHardwareDataType                            │
│  ifconfig en0 | grep ether                                      │
│                                                                 │
│  # 脚本验证                                                     │
│  sudo ./scripts/clover_configurator.sh verify                   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                    第四阶段：启动iMessage服务                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  AppleScript脚本                                                │
│  └── imessage_sender.scpt                                       │
│                                                                 │
│  Python发送器                                                    │
│  └── src/sender.py                                              │
│                                                                 │
│  任务调度                                                       │
│  └── Celery + RabbitMQ/Redis                                    │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## 详细步骤

### 步骤1：准备macOS虚拟机

```bash
# 运行虚拟机配置脚本
chmod +x scripts/setup_vm.sh
sudo ./scripts/setup_vm.sh
# 选择 VMware Fusion 或 VirtualBox
# 配置资源: 4核CPU + 8GB RAM (开发) / 8核CPU + 16GB RAM (生产)
```

### 步骤2：安装Clover EFI

```bash
# 下载Clover安装包
# https://github.com/CloverHackyColor/CloverBootloader/releases

# 或者使用Clover Configurator内置安装功能
# Clover Configurator → 安装Clover到ESP
```

### 步骤3：五码注入

#### 方式A：命令行自动生成

```bash
# 全自动模式 (推荐)
sudo ./scripts/clover_configurator.sh auto

# 交互式模式 (手动输入五码)
sudo ./scripts/clover_configurator.sh install

# 仅验证当前配置
sudo ./scripts/clover_configurator.sh verify
```

#### 方式B：Clover Configurator GUI

1. 打开 Clover Configurator
2. 加载Clover EFI分区
3. 配置五码字段
4. 保存

### 步骤4：验证五码

```bash
# 验证配置
sudo ./scripts/clover_configurator.sh verify

# 预期输出:
# ========== 当前五码配置 ==========
# UUID:         A1B2C3D4-E5F6-7890-ABCD-EF1234567890
# BoardSerial:  C02ABC123DEF
# Serial:       ABC123XYZ456
# ROM:          001C424C8A9D
# MLB:          100000000ABCDEF1
# SmUUID:       B2C3D4E5-F6A7-8901-BCDE-F23456789012

# 系统验证
system_profiler SPHardwareDataType
# 确认Serial Number和Hardware UUID与配置一致

ifconfig en0 | grep ether
# 确认MAC地址与ROM字段一致
```

### 步骤5：启动服务

```bash
# Docker一键启动
cd docker
docker-compose up -d

# 或手动启动
pip install -r requirements.txt
celery -A src.scheduler worker --loglevel=info &
uvicorn src.api:app --host 0.0.0.0 --port 8000 &
```

## 五码生成规则

```python
# scripts/generate_five_codes.py

UUID = uuidgen()                    # 标准UUID格式
BoardSerial = "C02" + random(9)     # C02XXXXXXXXX
Serial = random(12, chars)          # 12位大写字母数字
ROM = "001C42" + random(6)          # Apple OUI前缀
MLB = "100000000" + random(8)       # 固定前缀+随机
SmUUID = uuidgen()                  # 标准UUID格式
```

## 文件位置

```
imessage-sender/
├── scripts/
│   ├── setup_vm.sh                    # 虚拟机配置
│   ├── clover_configurator.sh         # 五码注入脚本 ← 新增
│   └── imessage_sender.scpt           # AppleScript发送
├── config/
│   ├── five_codes_config.json         # 五码配置模板 ← 新增
│   └── ...
└── ...
```

## 常见问题

| 问题 | 原因 | 解决方案 |
|------|------|---------|
| 五码未生效 | 未从Clover引导 | 重启，选择Clover引导 |
| iMessage无法登录 | 五码不完整 | 验证所有六码都已设置 |
| MAC地址不匹配 | ROM字段格式错误 | 确保无冒号，12位hex |
| 重启后重置 | NVRAM未保存 | 重置NVRAM后重启 |
