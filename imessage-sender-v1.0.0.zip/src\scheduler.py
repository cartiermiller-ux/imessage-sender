"""
Celery任务调度器
管理消息发送任务的调度和执行
"""

import time
import logging
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from dataclasses import dataclass, field
from enum import Enum
import json

from celery import Celery
from celery.signals import task_success, task_failure, task_retry

logger = logging.getLogger(__name__)

# Celery应用配置
app = Celery('imessage_sender')

# 基础配置
app.conf.update(
    # 消息代理
    broker_url='amqp://guest:guest@localhost:5672//',
    # 结果后端
    result_backend='redis://localhost:6379/0',
    
    # 任务序列化
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json',
    timezone='Asia/Shanghai',
    enable_utc=True,
    
    # 任务路由
    task_routes={
        'tasks.send_message': {'queue': 'imessage'},
        'tasks.send_bulk': {'queue': 'imessage'},
        'tasks.schedule_message': {'queue': 'scheduler'},
    },
    
    # 限流配置
    task_annotations={
        'tasks.send_message': {
            'rate_limit': '10/m',  # 每分钟10条
            'time_limit': 30,
        },
        'tasks.send_bulk': {
            'time_limit': 3600,  # 批量任务最多1小时
        },
    },
    
    # 重试配置
    task_default_retry_delay=60,
    task_max_retries=3,
    
    # 结果过期时间
    result_expires=3600,
    
    # Worker配置
    worker_prefetch_multiplier=1,
    worker_max_tasks_per_child=100,
)

# 导入任务
app.config_from_object('config.celery_config')


@dataclass
class ScheduleConfig:
    """定时任务配置"""
    name: str
    message: str
    recipients: List[str]
    schedule_type: str  # 'interval', 'crontab', 'eta'
    schedule_value: Dict[str, Any]
    enabled: bool = True
    created_at: float = field(default_factory=time.time)
    last_run: Optional[float] = None
    
    
class MessageScheduler:
    """
    消息调度器
    
    支持:
    - 立即发送
    - 延迟发送
    - 定时发送
    - 周期发送
    """
    
    def __init__(self, celery_app: Celery = None):
        self.app = celery_app or app
        self._schedules: Dict[str, ScheduleConfig] = {}
    
    def send_now(
        self,
        recipient: str,
        message: str,
        priority: int = 5
    ):
        """
        立即发送
        
        Args:
            recipient: 收件人
            message: 消息内容
            priority: 优先级(1-10, 1最高)
        """
        from tasks import send_message
        
        task = send_message.apply_async(
            kwargs={
                'recipient': recipient,
                'message': message
            },
            priority=priority
        )
        
        logger.info(f"任务已提交: {task.id}")
        return task.id
    
    def send_at(
        self,
        recipient: str,
        message: str,
        send_time: datetime
    ):
        """
        定时发送
        
        Args:
            recipient: 收件人
            message: 消息内容
            send_time: 发送时间
        """
        from tasks import send_message
        
        # 计算ETA
        eta = send_time - datetime.now()
        countdown = max(0, eta.total_seconds())
        
        task = send_message.apply_async(
            kwargs={
                'recipient': recipient,
                'message': message
            },
            countdown=countdown
        )
        
        logger.info(f"定时任务已提交: {task.id}, 发送时间: {send_time}")
        return task.id
    
    def send_interval(
        self,
        recipient: str,
        message: str,
        interval_seconds: int
    ):
        """
        周期发送
        
        Args:
            recipient: 收件人
            message: 消息内容
            interval_seconds: 发送间隔(秒)
        """
        from tasks import send_message
        
        task = send_message.apply_async(
            kwargs={
                'recipient': recipient,
                'message': message
            }
        )
        
        # 调度下一次
        self._schedule_next(
            'interval',
            {
                'recipient': recipient,
                'message': message,
                'interval': interval_seconds,
                'prev_task_id': task.id
            }
        )
        
        return task.id
    
    def _schedule_next(self, schedule_type: str, params: Dict):
        """内部方法：调度下一次执行"""
        # 实现周期性调度的下一次调度逻辑
        pass
    
    def cancel_task(self, task_id: str) -> bool:
        """
        取消任务
        
        Args:
            task_id: 任务ID
            
        Returns:
            bool: 是否成功取消
        """
        try:
            self.app.control.revoke(task_id, terminate=True)
            logger.info(f"任务已取消: {task_id}")
            return True
        except Exception as e:
            logger.error(f"取消任务失败: {e}")
            return False
    
    def get_task_status(self, task_id: str) -> Dict[str, Any]:
        """
        获取任务状态
        
        Args:
            task_id: 任务ID
            
        Returns:
            Dict: 任务状态信息
        """
        from tasks import send_message
        
        result = self.app.AsyncResult(task_id)
        
        return {
            'task_id': task_id,
            'status': result.status,
            'result': result.result if result.ready() else None,
            'traceback': result.traceback if result.failed() else None,
        }
    
    def add_periodic_schedule(
        self,
        schedule_id: str,
        message: str,
        recipients: List[str],
        crontab: Dict[str, int]
    ) -> str:
        """
        添加周期调度
        
        Args:
            schedule_id: 调度ID
            message: 消息内容
            recipients: 收件人列表
            crontab: crontab配置 {minute, hour, day_of_week, ...}
            
        Returns:
            str: 调度ID
        """
        config = ScheduleConfig(
            name=schedule_id,
            message=message,
            recipients=recipients,
            schedule_type='crontab',
            schedule_value=crontab
        )
        
        self._schedules[schedule_id] = config
        
        # 注册Celery Beat任务
        from celery.schedules import crontab as celery_crontab
        
        self.app.conf.beat_schedule[schedule_id] = {
            'task': 'tasks.send_bulk',
            'schedule': celery_crontab(**crontab),
            'kwargs': {
                'recipients': recipients,
                'message': message
            }
        }
        
        logger.info(f"周期调度已添加: {schedule_id}")
        return schedule_id
    
    def remove_schedule(self, schedule_id: str) -> bool:
        """移除调度"""
        if schedule_id in self._schedules:
            del self._schedules[schedule_id]
            
            if schedule_id in self.app.conf.beat_schedule:
                del self.app.conf.beat_schedule[schedule_id]
            
            logger.info(f"调度已移除: {schedule_id}")
            return True
        
        return False


# 信号处理
@task_success.connect
def task_success_handler(sender=None, result=None, **kwargs):
    """任务成功完成"""
    logger.info(f"任务 {sender.request.id} 成功完成: {result}")


@task_failure.connect
def task_failure_handler(sender=None, exception=None, **kwargs):
    """任务执行失败"""
    logger.error(f"任务 {sender.request.id} 失败: {exception}")


@task_retry.connect
def task_retry_handler(sender=None, reason=None, **kwargs):
    """任务重试"""
    logger.warning(f"任务 {sender.request.id} 准备重试: {reason}")
