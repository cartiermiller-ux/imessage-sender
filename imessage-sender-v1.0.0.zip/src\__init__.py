"""
iMessage Sender - Python主模块
macOS虚拟机iMessage批量发送系统
"""

__version__ = "1.0.0"
__author__ = "Apple Developer"

from .sender import IMessageSender
from .scheduler import MessageScheduler
from .queue import MessageQueue

__all__ = ["IMessageSender", "MessageScheduler", "MessageQueue"]
