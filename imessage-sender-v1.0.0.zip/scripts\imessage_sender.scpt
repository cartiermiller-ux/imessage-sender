-- AppleScript: iMessage批量发送脚本
-- 用于在macOS虚拟机中通过Messages应用发送iMessage

-- 配置区域
property maxRetries : 3
property retryDelay : 2
property sendDelay : 1.5  -- 发送间隔(秒)，防止触发检测

-- 发送单条iMessage
-- @param recipient: 收件人手机号或Apple ID邮箱
-- @param messageText: 消息内容
-- @return: 成功返回true，失败返回false
on sendMessage(recipient, messageText)
    set retryCount to 0
    set sendSuccess to false
    
    repeat while retryCount < maxRetries and sendSuccess is false
        try
            -- 激活Messages应用
            tell application "Messages"
                activate
                delay 0.5
                
                -- 开始新对话
                set targetChat to service "SMS"
                set newChat to (make new chat with properties {service:targetChat})
                
                -- 添加收件人
                delay 0.3
                
                -- 发送消息
                send messageText to newChat
                
                delay sendDelay
                
                -- 关闭对话窗口
                close window 1
            end tell
            
            set sendSuccess to true
            log "消息已发送至: " & recipient
            
        on error errMsg number errNum
            set retryCount to retryCount + 1
            log "发送失败 (尝试 " & retryCount & "/" & maxRetries & "): " & errMsg
            
            if retryCount < maxRetries then
                delay retryDelay
            end if
        end try
    end repeat
    
    return sendSuccess
end sendMessage

-- 批量发送消息
-- @param recipientList: 收件人列表
-- @param messageText: 消息内容
-- @param progressCallback: 进度回调脚本对象
on sendBulkMessages(recipientList, messageText, progressCallback)
    set totalCount to length of recipientList
    set successCount to 0
    set failCount to 0
    
    repeat with i from 1 to totalCount
        set recipient to item i of recipientList
        
        -- 调用进度回调
        if progressCallback is not missing value then
            tell progressCallback to call({method:"onProgress", params:{current:i, total:totalCount, recipient:recipient}})
        end if
        
        -- 发送消息
        set success to sendMessage(recipient, messageText)
        
        if success then
            set successCount to successCount + 1
        else
            set failCount to failCount + 1
        end if
        
        -- 批次间延迟(更长的间隔，避免检测)
        if i < totalCount then
            delay sendDelay * 2
        end if
    end repeat
    
    -- 返回统计结果
    return {total:totalCount, success:successCount, failed:failCount}
end sendBulkMessages

-- 从文件读取收件人列表
-- @param filePath: 文件路径(每行一个收件人)
on readRecipientsFromFile(filePath)
    set recipientList to {}
    
    try
        set fileHandle to open for access file filePath
        repeat until end of file fileHandle
            set nextLine to read line fileHandle
            set nextLine to do shell script "echo " & quoted form of nextLine & " | tr -d '\\r\\n\\t '"
            if length of nextLine > 0 then
                set end of recipientList to nextLine
            end if
        end repeat
        close access file fileHandle
    on error
        try
            close access file filePath
        end try
        return {}
    end try
    
    return recipientList
end readRecipientsFromFile

-- 主执行入口(命令行调用)
on run argv
    if (count of argv) < 2 then
        display dialog "用法: osascript imessage_sender.scpt <收件人文件> <消息内容>" buttons {"确定"} default button 1
        return
    end if
    
    set recipientsFile to item 1 of argv
    set messageContent to item 2 of argv
    
    -- 读取收件人
    set recipientList to readRecipientsFromFile(recipientsFile)
    
    if (count of recipientList) = 0 then
        display dialog "错误: 未找到收件人" buttons {"确定"} default button 1
        return
    end if
    
    -- 执行发送
    set result to sendBulkMessages(recipientList, messageContent, missing value)
    
    -- 显示结果
    display dialog "发送完成!" & return & ¬
        "总计: " & total of result & return & ¬
        "成功: " & success of result & return & ¬
        "失败: " & failed of result buttons {"确定"} default button 1
end run
