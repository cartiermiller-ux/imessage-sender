# Clover Configurator 五码注入配置指南

## 概述

本项目使用 **Clover Configurator** 工具配合 VMware/VirtualBox macOS虚拟机进行五码（设备标识）配置，实现合规的企业级iMessage发送。

## 五码说明

| 五码 | Clover字段 | 用途 |
|-----|-----------|------|
| UUID | `SystemParameters.UUID` | 硬件唯一标识 |
| BoardSerial | `SMBIOS.BoardSerialNumber` | 主板序列号 |
| Serial | `SMBIOS.SerialNumber` | 系统序列号 |
| ROM | `RtVariables.ROM` | 网卡MAC地址 |
| MLB | `RtVariables.MLB` | 主板逻辑板编号 |
| SmUUID | `SMBUUID` | SMBios UUID |

## 使用流程

### 方式一：自动化脚本

```bash
# 1. 挂载并安装配置
sudo ./scripts/clover_configurator.sh install

# 2. 验证配置
sudo ./scripts/clover_configurator.sh verify

# 3. 全自动模式（自动生成五码）
sudo ./scripts/clover_configurator.sh auto
```

### 方式二：Clover Configurator GUI

#### 步骤1：安装Clover Configurator

1. 下载 [Clover Configurator](https://mackie100projects.altervista.org/download/clover-configurator/)
2. 安装到应用程序
3. 启动 Clover Configurator

#### 步骤2：加载Clover EFI

```
文件 → 加载Clover EFI分区
```

#### 步骤3：配置五码

展开左侧菜单，按以下路径配置：

```
┌─────────────────────────────────────────────────────────┐
│  Clover Configurator                                    │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ▼ SMBIOS                                              │
│    ├─ Product Name: Macmini8,1                        │
│    ├─ Serial Number: [输入序列号]                       │
│    ├─ Board Serial: [输入BoardSerial]                  │
│    ├─ SmUUID: [输入SmUUID]                             │
│    └─ Manufacturer: Apple Inc.                         │
│                                                         │
│  ▼ RT Variables                                         │
│    ├─ MLB: [输入MLB]                                   │
│    └─ ROM: [输入MAC地址]                               │
│                                                         │
│  ▼ System Parameters                                   │
│    ├─ Inject System ID: ✓                             │
│    └─ UUID: [输入UUID]                                 │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

#### 步骤4：保存配置

```
文件 → 保存
```

## 脚本命令详解

| 命令 | 说明 |
|------|------|
| `install` | 交互式安装配置 |
| `install --auto` | 自动生成五码并安装 |
| `generate` | 仅生成五码（显示在终端） |
| `verify` | 验证当前五码配置 |
| `backup` | 备份当前Clover配置 |
| `restore <dir>` | 从备份恢复配置 |
| `apply` | 应用配置到Clover |

## 配置文件

- **主配置**: `EFI/EFI/CLOVER/config.plist`
- **SMBIOS**: `EFI/EFI/CLOVER/SMBIOS.plist`
- **五码模板**: `config/five_codes_config.json`

## 五码格式要求

```
UUID:        XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX (标准UUID格式)
BoardSerial: C02XXXXXXXXXX (17字符，以C02开头)
Serial:      ABC123XYZ456 (12位大写字母数字)
ROM:         001C424C8A9D (12位十六进制，无冒号)
MLB:         100000000ABCDEF1 (17位)
SmUUID:      同UUID格式
```

## 验证方法

### macOS内验证

```bash
# 查看当前系统标识
system_profiler SPHardwareDataType

# 输出示例:
# Hardware Overview:
#   Model Name: Mac mini
#   Model Identifier: macmini8,1
#   Processor Name: Intel Core i5
#   Serial Number: ABC123XYZ456
#   Hardware UUID: A1B2C3D4-E5F6-7890-ABCD-EF1234567890

# 查看网络接口
ifconfig en0 | grep ether

# 输出示例:
# ether 00:1c:42:4c:8a:9d
```

### Clover验证

```bash
# 使用脚本验证
sudo ./scripts/clover_configurator.sh verify
```

## 故障排除

### 问题1：五码未生效

**解决**：
1. 重启虚拟机
2. 确保从Clover引导
3. 重置NVRAM: `sudo nvram -c && sudo reboot`

### 问题2：iMessage无法登录

**解决**：
1. 验证五码完整性
2. 检查SystemID是否正确注入
3. 尝试重置iMessage: `rm -rf ~/Library/Preferences/com.apple.iChat.plist`

### 问题3：macOS更新后五码重置

**解决**：
1. macOS更新前备份Clover配置
2. 更新后重新应用五码配置
3. 使用 `clover_configurator.sh backup` 定期备份

## 安全建议

1. **定期轮换**: 建议每月更换一次五码
2. **备份**: 每次修改前执行备份
3. **记录**: 记录已使用的五码，避免重复
4. **合规**: 仅用于企业授权的合规场景

## 参考资料

- [Clover Configurator 官方](https://mackie100projects.altervista.org/download/clover-configurator/)
- [Clover Wiki](https://github.com/CloverHackyColor/CloverBootloader/wiki)
- [MacSerial](https://github.com/acidanthera/MacInfoPkg)
