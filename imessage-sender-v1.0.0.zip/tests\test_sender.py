"""
单元测试
测试核心模块功能
"""

import unittest
import time
from unittest.mock import Mock, patch, MagicMock
import sys
import os

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.sender import IMessageSender, SendStatus, MessageResult
from src.queue import MessageQueue, QueueConfig, QueueBackend, QueueMonitor
from src.scheduler import MessageScheduler


class TestIMessageSender(unittest.TestCase):
    """测试iMessage发送器"""
    
    def setUp(self):
        """测试前准备"""
        self.sender = IMessageSender(
            script_path="./scripts/imessage_sender.scpt",
            min_interval=1.0,
            max_retries=2,
            retry_delay=1.0
        )
    
    @patch('subprocess.run')
    def test_check_platform_macOS(self, mock_run):
        """测试平台检测 - macOS"""
        mock_run.return_value = Mock(returncode=0)
        self.assertTrue(self.sender._check_platform())
    
    @patch('subprocess.run')
    def test_check_platform_non_macOS(self, mock_run):
        """测试平台检测 - 非macOS"""
        mock_run.return_value = Mock(returncode=1)
        self.assertFalse(self.sender._check_platform())
    
    def test_rate_limit(self):
        """测试速率限制"""
        self.sender._last_send_time = time.time()
        self.sender.min_interval = 1.0
        
        start = time.time()
        self.sender._rate_limit()
        elapsed = time.time() - start
        
        self.assertGreaterEqual(elapsed, 0.9)  # 允许小误差
    
    def test_message_result_creation(self):
        """测试消息结果创建"""
        result = MessageResult(
            recipient="test@example.com",
            status=SendStatus.SUCCESS,
            message="Test message",
            timestamp=time.time()
        )
        
        self.assertEqual(result.recipient, "test@example.com")
        self.assertEqual(result.status, SendStatus.SUCCESS)
        self.assertIsNone(result.error)


class TestMessageQueue(unittest.TestCase):
    """测试消息队列"""
    
    def setUp(self):
        """测试前准备"""
        self.config = QueueConfig(backend=QueueBackend.REDIS)
        self.queue = MessageQueue(self.config)
    
    def test_config_defaults(self):
        """测试配置默认值"""
        self.assertEqual(self.config.backend, QueueBackend.REDIS)
        self.assertEqual(self.config.redis_host, "localhost")
        self.assertEqual(self.config.redis_port, 6379)
        self.assertEqual(self.config.max_retry, 3)
    
    @patch('redis.Redis')
    def test_redis_connection(self, mock_redis):
        """测试Redis连接"""
        mock_instance = MagicMock()
        mock_redis.return_value = mock_instance
        mock_instance.ping.return_value = True
        
        client = self.queue._get_redis_connection()
        
        mock_redis.assert_called_once()
        mock_instance.ping.assert_called_once()


class TestQueueMonitor(unittest.TestCase):
    """测试队列监控"""
    
    def setUp(self):
        """测试前准备"""
        self.config = QueueConfig(backend=QueueBackend.REDIS)
        self.queue = MessageQueue(self.config)
        self.monitor = QueueMonitor(self.queue)
    
    def test_alert_thresholds(self):
        """测试告警阈值"""
        self.assertEqual(self.monitor._alert_thresholds['queue_depth'], 1000)
        self.assertEqual(self.monitor._alert_thresholds['dead_letter_ratio'], 0.1)
    
    @patch.object(QueueMonitor, 'get_metrics')
    def test_check_health_warning(self, mock_metrics):
        """测试健康检查 - 警告状态"""
        mock_metrics.return_value = {
            'queue_depth': 1500,
            'priority_depth': 0,
            'dlq_depth': 50,
            'consumer_count': 1
        }
        
        # Mock queue stats
        self.queue.get_queue_stats = Mock(return_value={
            'message_count': 1500,
            'consumer_count': 1,
            'dead_letter_queue': {'message_count': 50}
        })
        
        health = self.monitor.check_health()
        
        self.assertIn('alerts', health)
        self.assertIn('status', health)


class TestMessageScheduler(unittest.TestCase):
    """测试消息调度器"""
    
    def setUp(self):
        """测试前准备"""
        self.scheduler = MessageScheduler()
    
    def test_schedule_config_creation(self):
        """测试调度配置创建"""
        from src.scheduler import ScheduleConfig
        
        config = ScheduleConfig(
            name="test_schedule",
            message="Test message",
            recipients=["user1", "user2"],
            schedule_type="interval",
            schedule_value={"interval": 3600}
        )
        
        self.assertEqual(config.name, "test_schedule")
        self.assertEqual(len(config.recipients), 2)
        self.assertTrue(config.enabled)


if __name__ == '__main__':
    unittest.main()
