"""
消息队列管理
支持RabbitMQ和Redis作为消息代理
"""

import time
import logging
from typing import List, Optional, Dict, Any
from dataclasses import dataclass, field
from enum import Enum
import json
import redis
import pika
from pika.exceptions import AMQPConnectionError

logger = logging.getLogger(__name__)


class QueueBackend(Enum):
    """队列后端类型"""
    RABBITMQ = "rabbitmq"
    REDIS = "redis"


@dataclass
class QueueConfig:
    """队列配置"""
    backend: QueueBackend = QueueBackend.RABBITMQ
    
    # RabbitMQ配置
    rabbitmq_host: str = "localhost"
    rabbitmq_port: int = 5672
    rabbitmq_user: str = "guest"
    rabbitmq_password: str = "guest"
    rabbitmq_vhost: str = "/"
    
    # Redis配置
    redis_host: str = "localhost"
    redis_port: int = 6379
    redis_db: int = 0
    redis_password: Optional[str] = None
    
    # 队列名称
    queue_name: str = "imessage_queue"
    priority_queue_name: str = "imessage_priority"
    dead_letter_queue: str = "imessage_dlq"
    
    # 限流配置
    max_retry: int = 3
    message_ttl: int = 86400  # 24小时


class MessageQueue:
    """
    消息队列管理器
    
    提供统一的队列操作接口
    支持RabbitMQ和Redis两种后端
    """
    
    def __init__(self, config: QueueConfig = None):
        self.config = config or QueueConfig()
        self._connection = None
        self._channel = None
        self._redis_client = None
    
    def _get_rabbitmq_connection(self):
        """获取RabbitMQ连接"""
        if self._connection is None or self._connection.is_closed:
            credentials = pika.PlainCredentials(
                self.config.rabbitmq_user,
                self.config.rabbitmq_password
            )
            
            parameters = pika.ConnectionParameters(
                host=self.config.rabbitmq_host,
                port=self.config.rabbitmq_port,
                virtual_host=self.config.rabbitmq_vhost,
                credentials=credentials,
                heartbeat=600,
                blocked_connection_timeout=300
            )
            
            self._connection = pika.BlockingConnection(parameters)
            self._channel = self._connection.channel()
            
            # 声明队列
            self._channel.queue_declare(
                queue=self.config.queue_name,
                durable=True,
                arguments={
                    'x-message-ttl': self.config.message_ttl * 1000,
                    'x-dead-letter-exchange': '',
                    'x-dead-letter-routing-key': self.config.dead_letter_queue
                }
            )
            
            # 声明优先级队列
            self._channel.queue_declare(
                queue=self.config.priority_queue_name,
                durable=True,
                arguments={
                    'x-message-ttl': self.config.message_ttl * 1000,
                    'x-max-priority': 10
                }
            )
            
            # 声明死信队列
            self._channel.queue_declare(
                queue=self.config.dead_letter_queue,
                durable=True
            )
            
            logger.info("RabbitMQ连接已建立")
        
        return self._connection, self._channel
    
    def _get_redis_connection(self):
        """获取Redis连接"""
        if self._redis_client is None:
            self._redis_client = redis.Redis(
                host=self.config.redis_host,
                port=self.config.redis_port,
                db=self.config.redis_db,
                password=self.config.redis_password,
                decode_responses=True
            )
            
            # 测试连接
            self._redis_client.ping()
            logger.info("Redis连接已建立")
        
        return self._redis_client
    
    def connect(self):
        """建立连接"""
        if self.config.backend == QueueBackend.RABBITMQ:
            self._get_rabbitmq_connection()
        else:
            self._get_redis_connection()
    
    def disconnect(self):
        """断开连接"""
        if self._connection and not self._connection.is_closed:
            self._connection.close()
            self._connection = None
            self._channel = None
        
        if self._redis_client:
            self._redis_client.close()
            self._redis_client = None
    
    def publish(
        self,
        recipient: str,
        message: str,
        priority: int = 5,
        metadata: Optional[Dict] = None
    ) -> bool:
        """
        发布消息到队列
        
        Args:
            recipient: 收件人
            message: 消息内容
            priority: 优先级(1-10)
            metadata: 元数据
            
        Returns:
            bool: 是否成功
        """
        payload = {
            'recipient': recipient,
            'message': message,
            'timestamp': time.time(),
            'metadata': metadata or {}
        }
        
        try:
            if self.config.backend == QueueBackend.RABBITMQ:
                _, channel = self._get_rabbitmq_connection()
                
                # 选择队列(根据优先级)
                queue = (self.config.priority_queue_name 
                         if priority < 5 
                         else self.config.queue_name)
                
                channel.basic_publish(
                    exchange='',
                    routing_key=queue,
                    body=json.dumps(payload),
                    properties=pika.BasicProperties(
                        delivery_mode=2,  # 持久化
                        priority=priority
                    )
                )
                
            else:  # Redis
                client = self._get_redis_connection()
                client.lpush(
                    self.config.queue_name,
                    json.dumps(payload)
                )
            
            logger.debug(f"消息已发布: {recipient}")
            return True
            
        except Exception as e:
            logger.error(f"发布消息失败: {e}")
            return False
    
    def publish_batch(
        self,
        messages: List[Dict[str, str]],
        priority: int = 5
    ) -> int:
        """
        批量发布消息
        
        Args:
            messages: 消息列表 [{recipient, message}, ...]
            priority: 默认优先级
            
        Returns:
            int: 成功发布的数量
        """
        success_count = 0
        
        for msg in messages:
            if self.publish(
                msg['recipient'],
                msg['message'],
                priority,
                msg.get('metadata')
            ):
                success_count += 1
        
        return success_count
    
    def consume(
        self,
        callback,
        auto_ack: bool = False,
        priority_only: bool = False
    ):
        """
        消费消息
        
        Args:
            callback: 回调函数 (payload) -> bool
            auto_ack: 是否自动确认
            priority_only: 是否只消费优先级队列
        """
        if self.config.backend == QueueBackend.RABBITMQ:
            _, channel = self._get_rabbitmq_connection()
            
            queue = (self.config.priority_queue_name 
                     if priority_only 
                     else self.config.queue_name)
            
            def on_message(ch, method, properties, body):
                try:
                    payload = json.loads(body)
                    success = callback(payload)
                    
                    if not auto_ack:
                        if success:
                            ch.basic_ack(delivery_tag=method.delivery_tag)
                        else:
                            ch.basic_nack(
                                delivery_tag=method.delivery_tag,
                                requeue=False
                            )
                            
                except Exception as e:
                    logger.error(f"处理消息失败: {e}")
                    ch.basic_nack(
                        delivery_tag=method.delivery_tag,
                        requeue=False
                    )
            
            channel.basic_qos(prefetch_count=1)
            channel.basic_consume(
                queue=queue,
                on_message_callback=on_message,
                auto_ack=auto_ack
            )
            
            logger.info(f"开始消费队列: {queue}")
            channel.start_consuming()
            
        else:  # Redis
            client = self._get_redis_connection()
            
            while True:
                _, item = client.brpop(self.config.queue_name, timeout=5)
                if item:
                    try:
                        payload = json.loads(item)
                        success = callback(payload)
                        
                        if not success:
                            # 重新入队
                            client.lpush(self.config.queue_name, item)
                            
                    except Exception as e:
                        logger.error(f"处理消息失败: {e}")
    
    def get_queue_stats(self) -> Dict[str, Any]:
        """获取队列统计信息"""
        try:
            if self.config.backend == QueueBackend.RABBITMQ:
                _, channel = self._get_rabbitmq_connection()
                
                queue_info = channel.queue_declare(
                    queue=self.config.queue_name,
                    durable=True,
                    passive=True
                )
                
                priority_info = channel.queue_declare(
                    queue=self.config.priority_queue_name,
                    durable=True,
                    passive=True
                )
                
                dlq_info = channel.queue_declare(
                    queue=self.config.dead_letter_queue,
                    durable=True,
                    passive=True
                )
                
                return {
                    'backend': 'rabbitmq',
                    'queue_name': self.config.queue_name,
                    'message_count': queue_info.method.message_count,
                    'consumer_count': queue_info.method.consumer_count,
                    'priority_queue': {
                        'message_count': priority_info.method.message_count,
                        'consumer_count': priority_info.method.consumer_count
                    },
                    'dead_letter_queue': {
                        'message_count': dlq_info.method.message_count
                    }
                }
                
            else:  # Redis
                client = self._get_redis_connection()
                
                return {
                    'backend': 'redis',
                    'queue_name': self.config.queue_name,
                    'message_count': client.llen(self.config.queue_name),
                    'priority_queue': {
                        'message_count': client.llen(self.config.priority_queue_name)
                    },
                    'dead_letter_queue': {
                        'message_count': client.llen(self.config.dead_letter_queue)
                    }
                }
                
        except Exception as e:
            logger.error(f"获取队列统计失败: {e}")
            return {}
    
    def clear_queue(self) -> bool:
        """清空队列"""
        try:
            if self.config.backend == QueueBackend.RABBITMQ:
                _, channel = self._get_rabbitmq_connection()
                channel.queue_purge(self.config.queue_name)
                channel.queue_purge(self.config.priority_queue_name)
            else:  # Redis
                client = self._get_redis_connection()
                client.delete(
                    self.config.queue_name,
                    self.config.priority_queue_name
                )
            
            logger.info("队列已清空")
            return True
            
        except Exception as e:
            logger.error(f"清空队列失败: {e}")
            return False


class QueueMonitor:
    """
    队列监控器
    
    监控队列健康状态和性能指标
    """
    
    def __init__(self, queue: MessageQueue):
        self.queue = queue
        self._alert_thresholds = {
            'queue_depth': 1000,
            'dead_letter_ratio': 0.1,
            'consumer_count': 1
        }
    
    def check_health(self) -> Dict[str, Any]:
        """
        健康检查
        
        Returns:
            Dict: 健康状态和警告信息
        """
        stats = self.queue.get_queue_stats()
        
        alerts = []
        health_status = 'healthy'
        
        # 检查队列深度
        msg_count = stats.get('message_count', 0)
        if msg_count > self._alert_thresholds['queue_depth']:
            alerts.append(f"队列深度过高: {msg_count}")
            health_status = 'warning'
        
        # 检查死信比例
        dlq_count = stats.get('dead_letter_queue', {}).get('message_count', 0)
        if msg_count > 0 and dlq_count / msg_count > self._alert_thresholds['dead_letter_ratio']:
            alerts.append(f"死信比例过高: {dlq_count}/{msg_count}")
            health_status = 'critical'
        
        # 检查消费者数量
        consumer_count = stats.get('consumer_count', 0)
        if consumer_count < self._alert_thresholds['consumer_count']:
            alerts.append(f"消费者数量不足: {consumer_count}")
            health_status = 'warning'
        
        return {
            'status': health_status,
            'alerts': alerts,
            'stats': stats,
            'timestamp': time.time()
        }
    
    def get_metrics(self) -> Dict[str, float]:
        """获取性能指标"""
        stats = self.queue.get_queue_stats()
        
        return {
            'queue_depth': stats.get('message_count', 0),
            'priority_depth': stats.get('priority_queue', {}).get('message_count', 0),
            'dlq_depth': stats.get('dead_letter_queue', {}).get('message_count', 0),
            'consumer_count': stats.get('consumer_count', 0),
        }
