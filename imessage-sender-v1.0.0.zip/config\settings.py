"""
应用配置文件
包含所有应用级别的配置参数
"""

import os
from pathlib import Path

# 项目根目录
PROJECT_ROOT = Path(__file__).parent.parent

# 虚拟机配置
VM_CONFIG = {
    'name': 'macOS-VM',
    'memory_mb': 8192,
    'cpu_cores': 4,
    'disk_gb': 120,
    'vmware_path': '/Applications/VMware Fusion.app',
    'virtualbox_path': '/Applications/VirtualBox.app',
}

# AppleScript配置
APPLE_SCRIPT_CONFIG = {
    'script_path': str(PROJECT_ROOT / 'scripts' / 'imessage_sender.scpt'),
    'min_interval': 1.5,  # 最小发送间隔(秒)
    'max_retries': 3,
    'retry_delay': 2.0,
    'timeout': 30,
}

# RabbitMQ配置
RABBITMQ_CONFIG = {
    'host': os.getenv('RABBITMQ_HOST', 'localhost'),
    'port': int(os.getenv('RABBITMQ_PORT', 5672)),
    'user': os.getenv('RABBITMQ_USER', 'guest'),
    'password': os.getenv('RABBITMQ_PASSWORD', 'guest'),
    'vhost': os.getenv('RABBITMQ_VHOST', '/'),
    'connection_heartbeat': 600,
    'blocked_connection_timeout': 300,
}

# Redis配置
REDIS_CONFIG = {
    'host': os.getenv('REDIS_HOST', 'localhost'),
    'port': int(os.getenv('REDIS_PORT', 6379)),
    'db': int(os.getenv('REDIS_DB', 0)),
    'password': os.getenv('REDIS_PASSWORD', None),
    'socket_timeout': 5,
    'socket_connect_timeout': 5,
}

# 消息队列配置
QUEUE_CONFIG = {
    'default_queue': 'imessage_queue',
    'priority_queue': 'imessage_priority',
    'dead_letter_queue': 'imessage_dlq',
    'max_retry': 3,
    'message_ttl': 86400,  # 24小时
    'priority_levels': 10,
}

# 发送配置
SEND_CONFIG = {
    'min_interval': 1.5,  # 最小发送间隔
    'batch_size': 10,  # 每批数量
    'batch_delay': 10.0,  # 批次间隔
    'rate_limit_per_minute': 10,  # 每分钟限制
}

# 集群配置
CLUSTER_CONFIG = {
    'enabled': False,
    'worker_count': 2,
    'worker_queue': 'imessage',
    'scaling_policy': 'auto',  # 'auto', 'manual'
    'min_workers': 1,
    'max_workers': 10,
}

# 日志配置
LOG_CONFIG = {
    'level': 'INFO',
    'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    'file': str(PROJECT_ROOT / 'logs' / 'app.log'),
    'max_bytes': 10485760,  # 10MB
    'backup_count': 5,
}

# 数据库配置 (用于存储发送记录)
DATABASE_CONFIG = {
    'type': 'sqlite',  # 'sqlite', 'postgresql', 'mysql'
    'path': str(PROJECT_ROOT / 'data' / 'messages.db'),
}

# Docker配置
DOCKER_CONFIG = {
    'image': 'imessage-sender:latest',
    'network': 'imessage-network',
    'volumes': {
        str(PROJECT_ROOT / 'scripts'): {'bind': '/app/scripts', 'mode': 'ro'},
        str(PROJECT_ROOT / 'config'): {'bind': '/app/config', 'mode': 'ro'},
    },
    'environment': {
        'PYTHONUNBUFFERED': '1',
        'CELERY_BROKER_URL': 'amqp://guest:guest@rabbitmq:5672//',
        'CELERY_RESULT_BACKEND': 'redis://redis:6379/0',
    },
}

# Kubernetes配置
K8S_CONFIG = {
    'namespace': 'imessage-sender',
    'deployment_name': 'imessage-sender',
    'service_name': 'imessage-sender',
    'replica_count': 2,
    'resources': {
        'limits': {
            'cpu': '2',
            'memory': '4Gi',
        },
        'requests': {
            'cpu': '1',
            'memory': '2Gi',
        },
    },
}
