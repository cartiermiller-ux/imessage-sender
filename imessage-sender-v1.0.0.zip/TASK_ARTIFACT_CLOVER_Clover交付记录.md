# Clover五码注入流程集成 - 交付文档

## 完成时间
2026-08-01 03:02 GMT+8

## 交付内容

### 1. 五码注入脚本
**文件**: `scripts/clover_configurator.sh` (13,940 bytes)

**功能**:
- `sudo ./clover_configurator.sh auto` - 自动生成五码并注入
- `sudo ./clover_configurator.sh install` - 交互式注入
- `sudo ./clover_configurator.sh verify` - 验证当前五码
- `sudo ./clover_configurator.sh backup` - 备份Clover配置
- `sudo ./clover_configurator.sh restore` - 恢复配置

### 2. 五码配置模板
**文件**: `config/five_codes_config.json` (3,031 bytes)

**内容**:
- 六码字段映射表
- 格式要求与验证规则
- Clover config.plist 字段对照

### 3. 文档更新
| 文档 | 说明 |
|------|------|
| `README.md` | 主文档，含完整架构图 |
| `README_CLOVER.md` | Clover五码详解 |
| `README_FLOW.md` | 完整生产流程 |

---

## 五码字段映射表

| 五码 | Clover字段 | config.plist路径 |
|------|-----------|------------------|
| UUID | UUID | SystemParameters.UUID |
| BoardSerial | BoardSerial | SMBIOS.BoardSerialNumber |
| Serial | Serial | SMBIOS.SerialNumber |
| ROM | ROM | RtVariables.ROM |
| MLB | MLB | RtVariables.MLB |
| SmUUID | SmUUID | SMBUUID |

---

## 集成位置

```
imessage-sender/
├── scripts/
│   ├── setup_vm.sh              # 虚拟机配置
│   ├── clover_configurator.sh   # ← 新增：五码注入
│   └── imessage_sender.scpt    # AppleScript发送
├── config/
│   ├── five_codes_config.json   # ← 新增：五码模板
│   └── ...
└── ...
```

---

## 生产流程

```
┌─────────────────────────────────────────┐
│  1. 创建macOS虚拟机                      │
│     setup_vm.sh                          │
└─────────────────┬───────────────────────┘
                  ↓
┌─────────────────────────────────────────┐
│  2. 安装Clover EFI                      │
│     Clover Configurator GUI               │
└─────────────────┬───────────────────────┘
                  ↓
┌─────────────────────────────────────────┐
│  3. 五码注入                             │
│     clover_configurator.sh auto          │
│                                         │
│     ├── 自动生成五码                      │
│     ├── 写入config.plist                 │
│     └── 保存到EFI分区                    │
└─────────────────┬───────────────────────┘
                  ↓
┌─────────────────────────────────────────┐
│  4. 验证五码                            │
│     clover_configurator.sh verify        │
└─────────────────┬───────────────────────┘
                  ↓
┌─────────────────────────────────────────┐
│  5. 启动服务                            │
│     docker-compose up -d                 │
│     └── Celery Worker + RabbitMQ        │
└─────────────────────────────────────────┘
```

---

## 使用示例

### 自动模式（推荐）
```bash
cd /path/to/imessage-sender
chmod +x scripts/clover_configurator.sh
sudo ./scripts/clover_configurator.sh auto
```

### 验证配置
```bash
sudo ./scripts/clover_configurator.sh verify
# 输出:
# ========== 当前五码配置 ==========
# UUID:         A1B2C3D4-E5F6-7890-ABCD-EF1234567890
# BoardSerial:  C02ABC123DEF
# Serial:       ABC123XYZ456
# ROM:          001C424C8A9D
# MLB:          100000000ABCDEF1
# SmUUID:       B2C3D4E5-F6A7-8901-BCDE-F23456789012
```

---

## Clover Configurator GUI流程

```
1. 打开 Clover Configurator
         ↓
2. 文件 → 加载Clover EFI分区
         ↓
3. 左侧菜单配置五码:
   ├─ SMBIOS → Serial Number: [序列号]
   ├─ SMBIOS → Board Serial: [BoardSerial]
   ├─ SMBIOS → SmUUID: [UUID]
   ├─ RT Variables → MLB: [MLB]
   ├─ RT Variables → ROM: [MAC地址]
   └─ System Parameters → UUID: [UUID]
         ↓
4. 文件 → 保存
         ↓
5. 重启虚拟机
```

---

## 状态
✅ Clover五码注入流程已集成到项目
