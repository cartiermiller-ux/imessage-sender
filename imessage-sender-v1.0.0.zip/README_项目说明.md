# iMessage Sender - macOS虚拟机批量发送系统

基于 **Clover Configurator** 五码注入 + **macOS虚拟机** 的企业级iMessage批量发送系统。

## 系统架构

```
┌─────────────────────────────────────────────────────────────────────┐
│                        第一阶段：五码注入                              │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   Clover Configurator ──→ Clover EFI ──→ config.plist               │
│                                                                     │
│   五码字段映射:                                                      │
│   ┌──────────────┬─────────────────────────────────┐              │
│   │ UUID         │ SystemParameters.UUID            │              │
│   │ BoardSerial  │ SMBIOS.BoardSerialNumber         │              │
│   │ Serial       │ SMBIOS.SerialNumber              │              │
│   │ ROM          │ RtVariables.ROM                  │              │
│   │ MLB          │ RtVariables.MLB                  │              │
│   │ SmUUID       │ SMBUUID                          │              │
│   └──────────────┴─────────────────────────────────┘              │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────────┐
│                        第二阶段：虚拟机运行                           │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   macOS虚拟机 ──→ AppleScript ──→ Messages.app                     │
│                                                                     │
│   VMware Fusion / VirtualBox                                         │
│   Clover EFI 引导 + 五码生效                                         │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────────┐
│                        第三阶段：任务调度                             │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   用户请求 ──→ FastAPI ──→ RabbitMQ ──→ Celery Worker              │
│                              ↓                                      │
│                           Redis (结果存储)                          │
│                                                                     │
│   速率控制:                                                          │
│   • time.sleep(1.5) 单条间隔                                        │
│   • batch_delay(10.0) 批次间隔                                      │
│   • rate_limit: '10/m' 每分钟限流                                   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

## 核心流程

```
创建虚拟机 ──→ 安装Clover EFI ──→ 五码注入 ──→ 验证五码 ──→ 启动服务
     │                                      │
     │         ┌───────────────────────────┘
     │         ↓
     │    ┌────────┐
     └────│ Clover │
          │config. │
          │plist   │  ← 六码配置存储
          └────────┘
                ↓
          ┌─────────────┐
          │ macOS Messages.app │
          │ (iMessage发送)     │
          └─────────────┘
                ↓
          ┌─────────────┐
          │ Celery调度器  │
          │ (批量任务)    │
          └─────────────┘
```

## 功能特性

| 特性 | 说明 |
|------|------|
| ✅ **Clover五码注入** | Clover Configurator + Clover EFI 设备标识配置 |
| ✅ **VMware/VirtualBox** | 虚拟机自动化配置 |
| ✅ **AppleScript自动化** | 原生控制Messages.app发送iMessage |
| ✅ **Celery任务调度** | RabbitMQ/Redis完整任务队列 |
| ✅ **速率控制** | time.sleep() + Celery限流，避免检测 |
| ✅ **Docker/K8s部署** | 企业级集群水平扩展 |
| ✅ **REST API** | FastAPI完整接口 |
| ✅ **监控面板** | Flower实时监控 |

## 快速开始

### 1. 环境要求

| 组件 | 版本 | 用途 |
|------|------|------|
| macOS虚拟机 | 10.15+ | iMessage发送 |
| Clover EFI | 最新版 | 引导+五码 |
| Clover Configurator | 最新版 | 五码配置GUI |
| Python | 3.9+ | 运行环境 |
| RabbitMQ | 3.12+ | 消息队列 |
| Redis | 7.0+ | 结果后端 |
| Docker | 20.10+ | 容器化部署 |

### 2. 五码注入流程

#### 方式A：Clover Configurator GUI（推荐新手）

```bash
# 1. 下载安装 Clover Configurator
https://mackie100projects.altervista.org/download/clover-configurator/

# 2. 打开应用 → 加载Clover EFI分区

# 3. 配置五码（见下表）
┌────────────────────────────────────────────────┐
│  SMBIOS                                         │
│  ├─ Product Name: Macmini8,1                   │
│  ├─ Serial Number: [企业授权序列号]             │
│  ├─ Board Serial: [企业授权BoardSerial]        │
│  ├─ SmUUID: [企业授权UUID]                     │
│                                                 │
│  RT Variables                                   │
│  ├─ MLB: [企业授权MLB]                        │
│  └─ ROM: [企业授权MAC]                        │
│                                                 │
│  System Parameters                             │
│  ├─ Inject System ID: ✓                        │
│  └─ UUID: [企业授权UUID]                       │
└────────────────────────────────────────────────┘

# 4. 保存配置
```

#### 方式B：命令行脚本（推荐自动化）

```bash
# 1. 运行五码注入脚本
chmod +x scripts/clover_configurator.sh
sudo ./scripts/clover_configurator.sh auto

# 2. 验证五码
sudo ./scripts/clover_configurator.sh verify

# 3. 预期输出:
# ========== 当前五码配置 ==========
# UUID:         A1B2C3D4-E5F6-7890-ABCD-EF1234567890
# BoardSerial:  C02ABC123DEF
# Serial:       ABC123XYZ456
# ROM:          001C424C8A9D
# MLB:          100000000ABCDEF1
# SmUUID:       B2C3D4E5-F6A7-8901-BCDE-F23456789012
```

### 3. 虚拟机配置

```bash
# 虚拟机配置脚本
chmod +x scripts/setup_vm.sh
sudo ./scripts/setup_vm.sh

# 选择:
# [1] VMware Fusion
# [2] VirtualBox

# 资源规划:
# 开发测试: 4核CPU + 8GB RAM
# 批量发信: 8核CPU + 16GB RAM
```

### 4. Docker部署

```bash
cd docker
docker-compose up -d

# 查看服务状态
docker-compose ps

# 查看Worker日志
docker-compose logs -f celery-worker
```

## 项目结构

```
imessage-sender/
├── src/                          # Python源代码
│   ├── sender.py                # iMessage发送器
│   ├── scheduler.py             # Celery调度器
│   ├── queue.py                 # 消息队列管理
│   ├── tasks.py                 # Celery任务
│   └── api.py                   # FastAPI服务
│
├── scripts/                     # 脚本
│   ├── setup_vm.sh              # 虚拟机配置
│   ├── clover_configurator.sh   # 五码注入脚本
│   └── imessage_sender.scpt     # AppleScript发送
│
├── config/                      # 配置文件
│   ├── five_codes_config.json   # 五码配置模板
│   ├── celery_config.py         # Celery配置
│   └── settings.py              # 应用配置
│
├── docker/                      # Docker部署
│   ├── Dockerfile
│   └── docker-compose.yml
│
├── k8s/                         # Kubernetes部署
│   └── namespace.yaml
│
├── tests/                       # 测试
│   └── test_sender.py
│
├── README.md                    # 主文档
├── README_CLOVER.md             # Clover五码详解
├── README_FLOW.md               # 完整流程文档
└── requirements.txt
```

## API使用

### 发送单条消息

```bash
curl -X POST http://localhost:8000/send \
  -H "Content-Type: application/json" \
  -d '{
    "recipient": "+1234567890",
    "message": "Hello from iMessage Sender!",
    "priority": 5
  }'
```

### 批量发送

```bash
curl -X POST http://localhost:8000/send/bulk \
  -H "Content-Type: application/json" \
  -d '{
    "recipients": ["+1234567890", "+0987654321"],
    "message": "Bulk message",
    "batch_size": 10,
    "batch_delay": 10.0
  }'
```

### 查看队列状态

```bash
curl http://localhost:8000/queue/stats
```

## 五码详解

### 字段说明

| 五码 | Clover字段 | 格式要求 | 说明 |
|------|-----------|---------|------|
| UUID | SystemParameters.UUID | XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX | 硬件唯一标识 |
| BoardSerial | SMBIOS.BoardSerialNumber | C02XXXXXXXXX (17字符) | 主板序列号 |
| Serial | SMBIOS.SerialNumber | 12位大写字母数字 | 系统序列号 |
| ROM | RtVariables.ROM | 12位hex无冒号 | 网卡MAC地址 |
| MLB | RtVariables.MLB | 17位字母数字 | 主板编号 |
| SmUUID | SMBUUID | 同UUID格式 | SMBios UUID |

### 五码生成规则

```python
# 自动生成示例
UUID = uuidgen()                     # A1B2C3D4-E5F6-7890-ABCD-EF1234567890
BoardSerial = "C02" + random(9)     # C02ABC123DEF
Serial = random(12, "A-Z0-9")       # ABC123XYZ456
ROM = "001C42" + random(6)           # 001C424C8A9D (Apple OUI)
MLB = "100000000" + random(8)        # 100000000ABCDEF1
SmUUID = uuidgen()
```

### Clover配置文件位置

```
EFI分区
└── EFI
    └── CLOVER
        ├── config.plist    ← 六码主配置
        ├── SMBIOS.plist    ← SMBIOS信息
        └── tools/          ← Clover工具
```

## 集群扩展

### Docker水平扩展

```bash
# 扩展到5个Worker
docker-compose up -d --scale celery-worker=5

# 计算吞吐量:
# 5 Workers × 4并发 × 10条/分钟 = 200条/分钟
```

### Kubernetes自动扩缩容

```yaml
# k8s/namespace.yaml 中已配置
spec:
  replicas: 2  # 基础副本
---
# 可选 HPA 配置
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: imessage-celery-hpa
spec:
  minReplicas: 1
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        averageUtilization: 70
```

## 监控

### Flower面板

```bash
# 启动
docker-compose --profile monitoring up -d flower

# 访问
http://localhost:5555
```

### API健康检查

```bash
curl http://localhost:8000/health
```

## 合规声明

⚠️ **重要提示**: 本项目仅供技术学习和企业内部合规使用。请遵守:
- Apple服务条款
- 企业开发者协议
- 当地法律法规
- 接收方同意原则

## License

MIT License
