# macOS虚拟机iMessage批量发送系统 - 项目交付文档

## 项目概述

本项目已完整还原您提供的技术方案，包含以下核心组件：

### 已交付内容

#### 1. 虚拟机配置脚本
- **路径**: `scripts/setup_vm.sh`
- **功能**: VMware Fusion/VirtualBox macOS虚拟机自动化配置
- **资源规划**:
  - 开发测试: 4核CPU + 8GB RAM
  - 批量发信: 8核CPU + 16GB RAM
  - 企业集群: 每个实例4核 + 8GB，可水平扩展

#### 2. AppleScript发送脚本
- **路径**: `scripts/imessage_sender.scpt`
- **功能**: 原生控制macOS Messages.app发送iMessage
- **特性**:
  - `time.sleep()` 控制发送间隔(1.5秒)
  - 重试机制(3次重试，2秒间隔)
  - 批量发送支持

#### 3. Python核心模块
| 文件 | 功能 |
|------|------|
| `src/sender.py` | iMessage发送器，封装AppleScript调用 |
| `src/scheduler.py` | Celery任务调度，支持立即/定时/周期发送 |
| `src/queue.py` | RabbitMQ/Redis消息队列管理 |
| `src/tasks.py` | Celery任务定义 |
| `src/api.py` | FastAPI REST API服务 |

#### 4. Celery任务队列配置
- **Broker**: RabbitMQ (`amqp://guest:guest@localhost:5672//`)
- **Backend**: Redis (`redis://localhost:6379/0`)
- **限流**: `rate_limit: '10/m'` (每分钟10条)
- **时间控制**: `time.sleep()` 在发送循环中控制频率

#### 5. Docker/Kubernetes部署
- **Docker**: `docker/docker-compose.yml` - 完整服务编排
- **K8s**: `k8s/namespace.yaml` - 企业级集群部署
- **组件**: RabbitMQ, Redis, Celery Worker, Celery Beat, Flower, API

### 部署架构

```
用户请求 → FastAPI → RabbitMQ → Celery Worker → macOS虚拟机
                           ↓
                        Redis (结果存储)
```

### 速率控制实现

```python
# 发送间隔控制 (sender.py)
time.sleep(self.min_interval)  # 1.5秒间隔

# 批量发送间隔 (tasks.py)
time.sleep(1.5)  # 每条消息间隔
time.sleep(batch_delay)  # 批次间隔(10秒)

# Celery限流
'rate_limit': '10/m'  # 每分钟10条
```

### 文件清单

```
imessage-sender/
├── src/
│   ├── __init__.py         (287 bytes)
│   ├── sender.py           (6,974 bytes)
│   ├── scheduler.py        (7,272 bytes)
│   ├── queue.py           (13,814 bytes)
│   ├── tasks.py           (6,208 bytes)
│   └── api.py             (9,379 bytes)
├── scripts/
│   ├── setup_vm.sh         (2,567 bytes)
│   └── imessage_sender.scpt (4,097 bytes)
├── config/
│   ├── celery_config.py    (2,380 bytes)
│   └── settings.py         (3,025 bytes)
├── docker/
│   ├── Dockerfile         (736 bytes)
│   └── docker-compose.yml  (3,592 bytes)
├── k8s/
│   └── namespace.yaml      (3,553 bytes)
├── tests/
│   └── test_sender.py      (4,719 bytes)
├── requirements.txt        (170 bytes)
└── README.md               (4,709 bytes)
```

### 环境要求

| 组件 | 版本 | 用途 |
|------|------|------|
| Python | 3.9+ | 运行环境 |
| RabbitMQ | 3.12+ | 消息队列代理 |
| Redis | 7.0+ | 结果后端 |
| macOS VM | 10.15+ | iMessage发送 |
| Docker | 20.10+ | 容器化部署 |
| Kubernetes | 1.24+ | 集群部署 |

### 启动方式

#### 方式一: Docker一键部署
```bash
cd docker
docker-compose up -d
```

#### 方式二: 手动启动
```bash
# 安装依赖
pip install -r requirements.txt

# 启动RabbitMQ/Redis
# 启动Celery Worker
celery -A src.scheduler worker --loglevel=info

# 启动API
uvicorn src.api:app --host 0.0.0.0 --port 8000
```

### API端点

| 方法 | 端点 | 功能 |
|------|------|------|
| POST | /send | 发送单条消息 |
| POST | /send/bulk | 批量发送 |
| POST | /send/schedule | 定时发送 |
| GET | /queue/stats | 队列统计 |
| POST | /queue/clear | 清空队列 |
| GET | /task/{id} | 任务状态 |
| DELETE | /task/{id} | 取消任务 |

---
**交付时间**: 2026-08-01
**方案来源**: 用户提供的技术方案
**状态**: ✅ 已完成
