"""
iMessage发送器核心模块
通过AppleScript接口控制macOS Messages应用
"""

import subprocess
import time
import logging
from typing import List, Dict, Optional, Callable
from dataclasses import dataclass
from enum import Enum
import os

logger = logging.getLogger(__name__)


class SendStatus(Enum):
    """发送状态枚举"""
    PENDING = "pending"
    SENDING = "sending"
    SUCCESS = "success"
    FAILED = "failed"
    RATE_LIMITED = "rate_limited"


@dataclass
class MessageResult:
    """消息发送结果"""
    recipient: str
    status: SendStatus
    message: str
    timestamp: float
    retry_count: int = 0
    error: Optional[str] = None


class IMessageSender:
    """
    iMessage发送器
    
    通过AppleScript与macOS Messages应用交互
    支持批量发送、速率控制、错误重试
    """
    
    def __init__(
        self,
        script_path: str = "./scripts/imessage_sender.scpt",
        min_interval: float = 1.5,
        max_retries: int = 3,
        retry_delay: float = 2.0
    ):
        """
        初始化发送器
        
        Args:
            script_path: AppleScript脚本路径
            min_interval: 最小发送间隔(秒)
            max_retries: 最大重试次数
            retry_delay: 重试延迟(秒)
        """
        self.script_path = script_path
        self.min_interval = min_interval
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self._rate_limit_count = 0
        self._last_send_time = 0
        
    def _check_platform(self) -> bool:
        """检查是否在macOS平台"""
        return subprocess.run(
            ["sw_vers"],
            capture_output=True,
            text=True
        ).returncode == 0
    
    def _run_applescript(self, script: str, timeout: int = 30) -> tuple:
        """
        执行AppleScript
        
        Args:
            script: AppleScript脚本内容或文件路径
            timeout: 超时时间(秒)
            
        Returns:
            (success: bool, output: str, error: str)
        """
        try:
            if os.path.exists(script):
                # 从文件执行
                result = subprocess.run(
                    ["osascript", script],
                    capture_output=True,
                    text=True,
                    timeout=timeout
                )
            else:
                # 直接执行脚本
                result = subprocess.run(
                    ["osascript", "-e", script],
                    capture_output=True,
                    text=True,
                    timeout=timeout
                )
            
            success = result.returncode == 0
            return success, result.stdout.strip(), result.stderr.strip()
            
        except subprocess.TimeoutExpired:
            return False, "", "执行超时"
        except Exception as e:
            return False, "", str(e)
    
    def _rate_limit(self):
        """速率限制：确保发送间隔不小于最小间隔"""
        current_time = time.time()
        elapsed = current_time - self._last_send_time
        
        if elapsed < self.min_interval:
            sleep_time = self.min_interval - elapsed
            logger.debug(f"速率限制: 等待 {sleep_time:.2f} 秒")
            time.sleep(sleep_time)
        
        self._last_send_time = time.time()
    
    def send_single(
        self,
        recipient: str,
        message: str,
        progress_callback: Optional[Callable] = None
    ) -> MessageResult:
        """
        发送单条消息
        
        Args:
            recipient: 收件人(手机号或Apple ID)
            message: 消息内容
            progress_callback: 进度回调函数
            
        Returns:
            MessageResult: 发送结果
        """
        if not self._check_platform():
            return MessageResult(
                recipient=recipient,
                status=SendStatus.FAILED,
                message=message,
                timestamp=time.time(),
                error="非macOS平台"
            )
        
        self._rate_limit()
        
        # 构建AppleScript
        script = f'''
        tell application "Messages"
            activate
            delay 0.5
            
            set targetService to service "SMS"
            set newChat to make new chat with properties {{service:targetService}}
            delay 0.3
            
            send "{message}" to newChat
            delay 0.5
            
            close window 1
        end tell
        '''
        
        result = self._run_applescript(script)
        
        if result[0]:
            logger.info(f"消息已发送至 {recipient}")
            return MessageResult(
                recipient=recipient,
                status=SendStatus.SUCCESS,
                message=message,
                timestamp=time.time()
            )
        else:
            logger.error(f"发送失败: {result[2]}")
            return MessageResult(
                recipient=recipient,
                status=SendStatus.FAILED,
                message=message,
                timestamp=time.time(),
                error=result[2]
            )
    
    def send_bulk(
        self,
        recipients: List[str],
        message: str,
        progress_callback: Optional[Callable] = None
    ) -> Dict[str, MessageResult]:
        """
        批量发送消息
        
        Args:
            recipients: 收件人列表
            message: 消息内容
            progress_callback: 进度回调函数(current, total, recipient)
            
        Returns:
            Dict[str, MessageResult]: 结果字典，键为收件人
        """
        results = {}
        total = len(recipients)
        
        logger.info(f"开始批量发送: {total} 个收件人")
        
        for idx, recipient in enumerate(recipients, 1):
            if progress_callback:
                progress_callback(idx, total, recipient)
            
            result = self.send_single(recipient, message)
            results[recipient] = result
            
            # 批次间隔(更长)
            if idx < total:
                time.sleep(self.min_interval * 2)
        
        # 统计结果
        success_count = sum(1 for r in results.values() if r.status == SendStatus.SUCCESS)
        logger.info(f"批量发送完成: 成功 {success_count}/{total}")
        
        return results
    
    def send_with_retry(
        self,
        recipient: str,
        message: str,
        max_retries: Optional[int] = None
    ) -> MessageResult:
        """
        带重试的发送
        
        Args:
            recipient: 收件人
            message: 消息内容
            max_retries: 最大重试次数(None使用默认值)
            
        Returns:
            MessageResult: 最终发送结果
        """
        max_retries = max_retries or self.max_retries
        result = None
        
        for attempt in range(max_retries):
            result = self.send_single(recipient, message)
            
            if result.status == SendStatus.SUCCESS:
                return result
            
            if attempt < max_retries - 1:
                delay = self.retry_delay * (attempt + 1)
                logger.info(f"重试 ({attempt + 1}/{max_retries})，等待 {delay} 秒")
                time.sleep(delay)
        
        result.retry_count = max_retries
        return result
