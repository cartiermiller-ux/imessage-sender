"""
Celery配置文件
包含所有Celery相关的配置参数
"""

from kombu import Exchange, Queue

# Broker配置
broker_url = 'amqp://guest:guest@localhost:5672//'
result_backend = 'redis://localhost:6379/0'

# 序列化配置
task_serializer = 'json'
accept_content = ['json']
result_serializer = 'json'
timezone = 'Asia/Shanghai'
enable_utc = True

# 任务路由
task_routes = {
    'tasks.send_message': {
        'queue': 'imessage',
        'routing_key': 'imessage.send'
    },
    'tasks.send_bulk': {
        'queue': 'imessage',
        'routing_key': 'imessage.bulk'
    },
    'tasks.schedule_message': {
        'queue': 'scheduler',
        'routing_key': 'scheduler.schedule'
    },
    'tasks.queue_consumer': {
        'queue': 'consumer',
        'routing_key': 'consumer.process'
    },
    'tasks.health_check': {
        'queue': 'monitor',
        'routing_key': 'monitor.health'
    },
}

# 任务队列定义
task_queues = (
    Queue('imessage', Exchange('imessage'), routing_key='imessage.#'),
    Queue('scheduler', Exchange('scheduler'), routing_key='scheduler.#'),
    Queue('consumer', Exchange('consumer'), routing_key='consumer.#'),
    Queue('monitor', Exchange('monitor'), routing_key='monitor.#'),
)

# 限流配置
task_annotations = {
    'tasks.send_message': {
        'rate_limit': '10/m',  # 每分钟10条
        'time_limit': 30,
        'soft_time_limit': 25,
    },
    'tasks.send_bulk': {
        'time_limit': 3600,
        'soft_time_limit': 3500,
    },
    'tasks.schedule_message': {
        'time_limit': 60,
    },
}

# 重试配置
task_default_retry_delay = 60
task_max_retries = 3
task_acks_late = True
task_reject_on_worker_lost = True

# 结果配置
result_expires = 3600  # 1小时
result_persistent = True

# Worker配置
worker_prefetch_multiplier = 1
worker_max_tasks_per_child = 100
worker_disable_rate_limits = False

# Beat调度配置 (定时任务)
beat_schedule = {
    'cleanup-every-hour': {
        'task': 'tasks.cleanup',
        'schedule': 3600.0,  # 每小时
        'options': {'queue': 'monitor'}
    },
    'health-check-every-5min': {
        'task': 'tasks.health_check',
        'schedule': 300.0,  # 每5分钟
        'options': {'queue': 'monitor'}
    },
}

# 日志配置
worker_log_format = '[%(asctime)s: %(levelname)s/%(processName)s] %(message)s'
worker_task_log_format = '[%(asctime)s: %(levelname)s/%(processName)s][%(task_name)s(%(task_id)s)] %(message)s'

# 安全配置
task_ignore_result = False
task_track_started = True
