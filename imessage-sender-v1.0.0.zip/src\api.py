"""
FastAPI Web服务
提供REST API接口
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
import logging

from .scheduler import MessageScheduler
from .queue import MessageQueue, QueueConfig, QueueBackend, QueueMonitor
from .sender import SendStatus

logger = logging.getLogger(__name__)

# FastAPI应用
app = FastAPI(
    title="iMessage Sender API",
    description="macOS虚拟机iMessage批量发送系统API",
    version="1.0.0"
)

# CORS配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 全局组件
scheduler = MessageScheduler()
queue_config = QueueConfig(backend=QueueBackend.REDIS)
queue = MessageQueue(queue_config)
monitor = QueueMonitor(queue)


# ==================== 请求模型 ====================

class SendMessageRequest(BaseModel):
    """发送单条消息请求"""
    recipient: str = Field(..., description="收件人手机号或Apple ID")
    message: str = Field(..., description="消息内容", max_length=5000)
    priority: int = Field(5, ge=1, le=10, description="优先级(1-10)")


class SendBulkRequest(BaseModel):
    """批量发送请求"""
    recipients: List[str] = Field(..., description="收件人列表")
    message: str = Field(..., description="消息内容", max_length=5000)
    batch_size: int = Field(10, ge=1, le=100, description="每批数量")
    batch_delay: float = Field(10.0, ge=0, description="批次间隔(秒)")


class ScheduleRequest(BaseModel):
    """定时发送请求"""
    recipient: str = Field(..., description="收件人")
    message: str = Field(..., description="消息内容")
    send_time: datetime = Field(..., description="发送时间")


class QueuePublishRequest(BaseModel):
    """队列发布请求"""
    recipient: str = Field(..., description="收件人")
    message: str = Field(..., description="消息内容")
    priority: int = Field(5, ge=1, le=10, description="优先级")


# ==================== 响应模型 ====================

class TaskResponse(BaseModel):
    """任务响应"""
    task_id: str
    status: str
    message: str


class SendResultResponse(BaseModel):
    """发送结果响应"""
    recipient: str
    status: str
    timestamp: float


class QueueStatsResponse(BaseModel):
    """队列统计响应"""
    backend: str
    queue_name: str
    message_count: int
    consumer_count: int
    priority_depth: int
    dlq_depth: int


class HealthResponse(BaseModel):
    """健康检查响应"""
    status: str
    timestamp: float
    components: Dict[str, Any]


# ==================== API端点 ====================

@app.get("/", tags=["Root"])
async def root():
    """API根路径"""
    return {
        "name": "iMessage Sender API",
        "version": "1.0.0",
        "docs": "/docs"
    }


@app.get("/health", response_model=HealthResponse, tags=["Health"])
async def health_check():
    """健康检查"""
    queue_health = monitor.check_health()
    
    return HealthResponse(
        status=queue_health.get('status', 'unknown'),
        timestamp=datetime.now().timestamp(),
        components={
            'queue': queue_health
        }
    )


# ==================== 发送接口 ====================

@app.post("/send", response_model=TaskResponse, tags=["Send"])
async def send_message(request: SendMessageRequest):
    """
    发送单条消息
    
    立即发送到RabbitMQ队列，由Worker执行发送
    """
    try:
        task_id = scheduler.send_now(
            recipient=request.recipient,
            message=request.message,
            priority=request.priority
        )
        
        return TaskResponse(
            task_id=task_id,
            status="queued",
            message=f"消息已加入队列，等待发送至 {request.recipient}"
        )
        
    except Exception as e:
        logger.error(f"发送失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/send/bulk", response_model=TaskResponse, tags=["Send"])
async def send_bulk(request: SendBulkRequest, background_tasks: BackgroundTasks):
    """
    批量发送消息
    
    将批量任务加入队列后台执行
    """
    try:
        # 这里简化处理，实际应该提交Celery任务
        task_id = f"bulk_{datetime.now().timestamp()}"
        
        # 模拟任务提交
        logger.info(f"批量任务已提交: {len(request.recipients)} 个收件人")
        
        return TaskResponse(
            task_id=task_id,
            status="queued",
            message=f"批量任务已提交，共 {len(request.recipients)} 个收件人"
        )
        
    except Exception as e:
        logger.error(f"批量发送失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/send/schedule", response_model=TaskResponse, tags=["Send"])
async def schedule_message(request: ScheduleRequest):
    """
    定时发送消息
    
    在指定时间发送消息
    """
    try:
        task_id = scheduler.send_at(
            recipient=request.recipient,
            message=request.message,
            send_time=request.send_time
        )
        
        return TaskResponse(
            task_id=task_id,
            status="scheduled",
            message=f"消息已定时，将在 {request.send_time} 发送"
        )
        
    except Exception as e:
        logger.error(f"定时发送失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ==================== 队列接口 ====================

@app.post("/queue/publish", response_model=dict, tags=["Queue"])
async def queue_publish(request: QueuePublishRequest):
    """
    直接发布到消息队列
    
    绕过调度器，直接发送到队列
    """
    try:
        queue.connect()
        success = queue.publish(
            recipient=request.recipient,
            message=request.message,
            priority=request.priority
        )
        queue.disconnect()
        
        if success:
            return {"status": "published", "recipient": request.recipient}
        else:
            raise HTTPException(status_code=500, detail="发布失败")
            
    except Exception as e:
        logger.error(f"队列发布失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/queue/stats", response_model=QueueStatsResponse, tags=["Queue"])
async def queue_stats():
    """获取队列统计信息"""
    try:
        queue.connect()
        stats = queue.get_queue_stats()
        queue.disconnect()
        
        metrics = monitor.get_metrics()
        
        return QueueStatsResponse(
            backend=stats.get('backend', 'unknown'),
            queue_name=stats.get('queue_name', ''),
            message_count=stats.get('message_count', 0),
            consumer_count=stats.get('consumer_count', 0),
            priority_depth=metrics.get('priority_depth', 0),
            dlq_depth=metrics.get('dlq_depth', 0)
        )
        
    except Exception as e:
        logger.error(f"获取队列统计失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/queue/clear", response_model=dict, tags=["Queue"])
async def queue_clear():
    """清空消息队列"""
    try:
        queue.connect()
        queue.clear_queue()
        queue.disconnect()
        
        return {"status": "cleared"}
        
    except Exception as e:
        logger.error(f"清空队列失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ==================== 任务接口 ====================

@app.get("/task/{task_id}", response_model=dict, tags=["Task"])
async def get_task_status(task_id: str):
    """获取任务状态"""
    try:
        status = scheduler.get_task_status(task_id)
        return status
        
    except Exception as e:
        logger.error(f"获取任务状态失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/task/{task_id}", response_model=dict, tags=["Task"])
async def cancel_task(task_id: str):
    """取消任务"""
    try:
        success = scheduler.cancel_task(task_id)
        
        if success:
            return {"status": "cancelled", "task_id": task_id}
        else:
            raise HTTPException(status_code=404, detail="任务未找到或已结束")
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"取消任务失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ==================== 调度接口 ====================

@app.post("/schedule/periodic", response_model=dict, tags=["Schedule"])
async def add_periodic_schedule(
    schedule_id: str,
    message: str,
    recipients: List[str],
    minute: int = 0,
    hour: int = 0
):
    """添加周期调度"""
    try:
        scheduler.add_periodic_schedule(
            schedule_id=schedule_id,
            message=message,
            recipients=recipients,
            crontab={'minute': minute, 'hour': hour}
        )
        
        return {
            "status": "created",
            "schedule_id": schedule_id
        }
        
    except Exception as e:
        logger.error(f"添加周期调度失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/schedule/{schedule_id}", response_model=dict, tags=["Schedule"])
async def remove_schedule(schedule_id: str):
    """移除周期调度"""
    try:
        success = scheduler.remove_schedule(schedule_id)
        
        if success:
            return {"status": "removed", "schedule_id": schedule_id}
        else:
            raise HTTPException(status_code=404, detail="调度未找到")
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"移除调度失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
