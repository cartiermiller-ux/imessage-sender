"""
Celery任务定义
消息发送的具体任务实现
"""

import time
import logging
from typing import List, Optional
from celery import shared_task
from celery.exceptions import MaxRetriesExceededError

from .sender import IMessageSender, SendStatus, MessageResult
from .queue import MessageQueue, QueueConfig, QueueBackend

logger = logging.getLogger(__name__)

# 全局发送器实例
_sender = None


def get_sender() -> IMessageSender:
    """获取发送器实例(单例)"""
    global _sender
    if _sender is None:
        _sender = IMessageSender()
    return _sender


@shared_task(
    bind=True,
    name='tasks.send_message',
    max_retries=3,
    default_retry_delay=60,
    acks_late=True
)
def send_message(
    self,
    recipient: str,
    message: str,
    delay: float = 1.5
) -> dict:
    """
    发送单条消息任务
    
    Args:
        recipient: 收件人
        message: 消息内容
        delay: 发送延迟(秒)
        
    Returns:
        dict: 任务结果
    """
    logger.info(f"[Task {self.request.id}] 准备发送消息至 {recipient}")
    
    # 延迟控制
    if delay > 0:
        time.sleep(delay)
    
    sender = get_sender()
    result = sender.send_single(recipient, message)
    
    if result.status == SendStatus.SUCCESS:
        return {
            'status': 'success',
            'recipient': recipient,
            'task_id': self.request.id,
            'timestamp': result.timestamp
        }
    else:
        # 重试
        try:
            raise self.retry(countdown=60, exc=Exception(result.error))
        except MaxRetriesExceededError:
            logger.error(f"[Task {self.request.id}] 重试次数已用完")
            return {
                'status': 'failed',
                'recipient': recipient,
                'error': result.error,
                'task_id': self.request.id
            }


@shared_task(
    bind=True,
    name='tasks.send_bulk',
    max_retries=1,
    acks_late=True
)
def send_bulk(
    self,
    recipients: List[str],
    message: str,
    batch_size: int = 10,
    batch_delay: float = 10.0
) -> dict:
    """
    批量发送消息任务
    
    Args:
        recipients: 收件人列表
        message: 消息内容
        batch_size: 每批数量
        batch_delay: 批次间隔(秒)
        
    Returns:
        dict: 批量任务结果
    """
    logger.info(f"[Task {self.request.id}] 开始批量发送，共 {len(recipients)} 个收件人")
    
    sender = get_sender()
    results = {
        'success': [],
        'failed': [],
        'total': len(recipients)
    }
    
    # 分批处理
    for i in range(0, len(recipients), batch_size):
        batch = recipients[i:i + batch_size]
        batch_num = i // batch_size + 1
        total_batches = (len(recipients) + batch_size - 1) // batch_size
        
        logger.info(f"[Task {self.request.id}] 处理批次 {batch_num}/{total_batches}")
        
        for recipient in batch:
            result = sender.send_single(recipient, message)
            
            if result.status == SendStatus.SUCCESS:
                results['success'].append(recipient)
            else:
                results['failed'].append({
                    'recipient': recipient,
                    'error': result.error
                })
            
            # 批次内间隔
            time.sleep(1.5)
        
        # 批次间延迟
        if batch_num < total_batches:
            logger.info(f"[Task {self.request.id}] 批次间隔: {batch_delay}秒")
            time.sleep(batch_delay)
    
    logger.info(
        f"[Task {self.request.id}] 批量发送完成: "
        f"成功 {len(results['success'])}/{results['total']}"
    )
    
    return {
        'status': 'completed',
        'task_id': self.request.id,
        'success_count': len(results['success']),
        'failed_count': len(results['failed']),
        'total': results['total'],
        'results': results
    }


@shared_task(
    bind=True,
    name='tasks.schedule_message',
    max_retries=3
)
def schedule_message(
    self,
    recipient: str,
    message: str,
    scheduled_time: float
) -> dict:
    """
    定时发送消息任务
    
    Args:
        recipient: 收件人
        message: 消息内容
        scheduled_time: 计划发送时间戳
        
    Returns:
        dict: 任务结果
    """
    now = time.time()
    wait_time = scheduled_time - now
    
    if wait_time > 0:
        logger.info(f"[Task {self.request.id}] 等待至 {scheduled_time} 发送")
        time.sleep(wait_time)
    
    return send_message(recipient, message)


@shared_task(
    bind=True,
    name='tasks.queue_consumer',
    acks_late=True
)
def queue_consumer(self, batch_size: int = 10) -> dict:
    """
    队列消费者任务
    
    从消息队列消费并处理消息
    
    Args:
        batch_size: 批处理大小
        
    Returns:
        dict: 处理结果
    """
    config = QueueConfig(backend=QueueBackend.RABBITMQ)
    queue = MessageQueue(config)
    queue.connect()
    
    processed = 0
    failed = 0
    
    def process_message(payload: dict) -> bool:
        nonlocal processed, failed
        
        try:
            recipient = payload['recipient']
            message = payload['message']
            metadata = payload.get('metadata', {})
            
            logger.info(f"[Consumer {self.request.id}] 处理消息: {recipient}")
            
            sender = get_sender()
            result = sender.send_single(recipient, message)
            
            if result.status == SendStatus.SUCCESS:
                processed += 1
                return True
            else:
                failed += 1
                return False
                
        except Exception as e:
            logger.error(f"[Consumer {self.request.id}] 处理失败: {e}")
            failed += 1
            return False
    
    try:
        queue.consume(process_message)
    finally:
        queue.disconnect()
    
    return {
        'status': 'completed',
        'processed': processed,
        'failed': failed,
        'task_id': self.request.id
    }


@shared_task(name='tasks.health_check')
def health_check() -> dict:
    """健康检查任务"""
    sender = get_sender()
    
    return {
        'status': 'healthy',
        'platform': 'macos' if sender._check_platform() else 'unknown',
        'timestamp': time.time()
    }


@shared_task(name='tasks.cleanup')
def cleanup() -> dict:
    """清理任务: 清理过期消息、重置状态等"""
    # 清理逻辑
    return {
        'status': 'completed',
        'timestamp': time.time()
    }
