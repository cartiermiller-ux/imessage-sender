#!/bin/bash
# macOS虚拟机安装与配置脚本
# 适用于 VMware Fusion 或 VirtualBox

set -e

VM_NAME="macOS-VM"
VM_MEMORY="8192"      # 8GB RAM
VM_CPU="4"            # 4 CPU cores
VM_DISK="120G"        # 120GB disk

echo "========================================="
echo "macOS虚拟机配置脚本"
echo "========================================="

# 检查是否以root运行（VMware Fusion需要）
if [[ $EUID -ne 0 ]]; then
   echo "此脚本需要root权限运行"
   echo "请使用: sudo $0"
   exit 1
fi

# 选择虚拟机软件
read -p "请选择虚拟机软件 [1]VMware Fusion [2]VirtualBox: " VMWARE_CHOICE

if [ "$VMWARE_CHOICE" = "1" ]; then
    echo "使用 VMware Fusion 配置..."
    
    # VMware Fusion 配置示例
    cat > "${VM_NAME}.vmx" << 'EOF'
.encoding = "UTF-8"
config.version = "8"
virtualHW.version = "18"
memSize = "8192"
numvcpus = "4"
cpuid.coresPerSocket = "2"
scsi0.present = "TRUE"
scsi0.virtualDev = "lsilogic"
scsi0:0.present = "TRUE"
scsi0:0.fileName = "macOS-VM.vmdk"
scsi0:0.deviceType = "scsi-hardDisk"
ide0:0.present = "TRUE"
ide0:0.fileName = "auto detect"
ide0:0.deviceType = "cdrom-raw"
ide0:0.startConnected = "TRUE"
ethernet0.present = "TRUE"
ethernet0.connectionType = "nat"
ethernet0.virtualDev = "vmxnet3"
ethernet0.addressType = "generated"
displayName = "macOS-VM"
guestOS = "darwin21-64"
nvram = "macOS-VM.nvram"
smc.present = "TRUE"
ethernet0.generateGuestAddress = "TRUE"
tools.syncTime = "TRUE"
toolScripts.afterResume = "TRUE"
toolScripts.beforeSuspend = "TRUE"
EOF

    echo "VMware Fusion 配置文件已创建: ${VM_NAME}.vmx"
    echo "请使用 VMware Fusion 打开此文件并安装 macOS"
    
elif [ "$VMWARE_CHOICE" = "2" ]; then
    echo "使用 VirtualBox 配置..."
    
    # VirtualBox 命令
    VBoxManage createvm --name "$VM_NAME" --register
    VBoxManage modifyvm "$VM_NAME" --memory "$VM_MEMORY" --cpus "$VM_CPU" --ostype "MacOS1015_64"
    VBoxManage modifyvm "$VM_NAME" --vram 128
    VBoxManage modifyvm "$VM_NAME" --graphicscontroller vmsvga
    VBoxManage modifyvm "$VM_NAME" --nic1 nat
    VBoxManage storagectl "$VM_NAME" --name "SATA" --add sata
    VBoxManage createhd --filename "${VM_NAME}.vdi" --size 122880 --format VDI
    VBoxManage storageattach "$VM_NAME" --storagectl "SATA" --port 0 --device 0 --type hdd --medium "${VM_NAME}.vdi"
    
    echo "VirtualBox 虚拟机 '$VM_NAME' 已创建"
    echo "下一步: 挂载 macOS 安装镜像并启动虚拟机"
fi

echo ""
echo "========================================="
echo "虚拟机资源配置"
echo "========================================="
echo "CPU核心数: $VM_CPU"
echo "内存大小: ${VM_MEMORY}MB"
echo "磁盘大小: $VM_DISK"
echo ""
echo "推荐资源配置:"
echo "- 开发测试: 4核CPU + 8GB RAM"
echo "- 批量发信: 8核CPU + 16GB RAM (可运行多个实例)"
echo "- 企业集群: 每个实例4核 + 8GB，可水平扩展"
